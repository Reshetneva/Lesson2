public interface Actions {
    void run();

    void jump();
}